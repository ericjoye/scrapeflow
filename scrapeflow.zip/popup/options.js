/**
 * @fileoverview ScrapeFlow options page controller. Manages license
 * activation, tier display, and usage stats on the options page.
 * @author Builder Agent
 * @date 2026-06-18
 */
(async function () {
  'use strict';

  const tierDisplay = document.getElementById('tierDisplay');
  const usageDisplay = document.getElementById('usageDisplay');
  const usageBar = document.getElementById('usageBar');
  const licenseKeyInput = document.getElementById('licenseKey');
  const activateBtn = document.getElementById('activateBtn');
  const activateStatus = document.getElementById('activateStatus');
  const upgradeSection = document.getElementById('upgradeSection');

  // ── Display update ──────────────────────────────────────────────────

  async function updateDisplay() {
    const tier = await ScrapeFlowTiers.getTier();
    const usage = await ScrapeFlowTiers.getUsage();
    const remaining = await ScrapeFlowTiers.getRemainingRows();
    const currentMonth = new Date().toISOString().slice(0, 7);
    const rowsUsed = usage.month === currentMonth ? usage.rowsThisMonth : 0;

    // Tier badge
    const tierLabels = { free: 'Free', pro: 'Pro', team: 'Team' };
    const tierClasses = { free: 'free', pro: 'pro', team: 'team' };
    tierDisplay.textContent = tierLabels[tier];
    tierDisplay.className = 'tier-display ' + tierClasses[tier];

    // Usage
    if (tier === 'free') {
      usageDisplay.textContent = `${rowsUsed} / ${ScrapeFlowTiers.FREE_ROW_LIMIT} rows used this month (${remaining} remaining)`;
      const pct = Math.min(100, (rowsUsed / ScrapeFlowTiers.FREE_ROW_LIMIT) * 100);
      usageBar.style.width = pct + '%';
      usageBar.className = 'usage-bar-fill ' + (pct >= 100 ? 'full' : pct >= 75 ? 'warn' : 'ok');
      upgradeSection.style.display = 'block';
    } else {
      usageDisplay.textContent = `${rowsUsed} rows used this month (unlimited)`;
      usageBar.style.width = '0%';
      usageBar.className = 'usage-bar-fill ok';
      upgradeSection.style.display = 'none';
    }
  }

  // ── License activation ──────────────────────────────────────────────

  activateBtn.addEventListener('click', async () => {
    const key = licenseKeyInput.value.trim();
    if (!key) {
      activateStatus.textContent = 'Please enter a license key.';
      activateStatus.className = 'activate-status error';
      return;
    }

    const result = await ScrapeFlowTiers.setLicense(key);
    if (result.valid) {
      activateStatus.textContent = `✓ Activated! You are now on the ${result.tier.charAt(0).toUpperCase() + result.tier.slice(1)} plan.`;
      activateStatus.className = 'activate-status success';
      licenseKeyInput.value = '';
      await updateDisplay();
    } else {
      activateStatus.textContent = '✗ Invalid license key. Use PRO-XXXX-XXXX or TEAM-XXXX-XXXX.';
      activateStatus.className = 'activate-status error';
    }
  });

  // Allow Enter key to submit
  licenseKeyInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      activateBtn.click();
    }
  });

  // ── Init ─────────────────────────────────────────────────────────────

  await updateDisplay();
})();

/**
 * @fileoverview ScrapeFlow popup controller. Manages scraping state,
 * detection results display, auto-extract, and data export.
 * @author Builder Agent
 * @date 2026-06-18
 */
(async function () {
  const startBtn = document.getElementById('startBtn');
  const clearBtn = document.getElementById('clearBtn');
  const exportCsv = document.getElementById('exportCsv');
  const exportJson = document.getElementById('exportJson');
  const statusEl = document.getElementById('status');
  const previewEl = document.getElementById('preview');
  const previewTable = document.getElementById('previewTable');
  const countEl = document.getElementById('count');
  const exportActions = document.getElementById('exportActions');
  const detectionResultsEl = document.getElementById('detectionResults');
  const detectionListEl = document.getElementById('detectionList');
  const upgradeBanner = document.getElementById('upgradeBanner');
  const upgradeBannerText = document.getElementById('upgradeBannerText');
  const upgradeBannerBtn = document.getElementById('upgradeBannerBtn');
  const upgradeBannerDismiss = document.getElementById('upgradeBannerDismiss');
  const tierBadge = document.getElementById('tierBadge');
  const dismissOnboarding = document.getElementById('dismissOnboarding');

  let isScraping = false;
  let scrapedData = [];
  let currentDetections = [];
  let tierBannerDismissed = false;

  // ── Init ─────────────────────────────────────────────────────────────

  async function init() {
    // Track popup open
    if (window.ScrapeFlowAnalytics) {
      await ScrapeFlowAnalytics.track('popup_opened');
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    // Load any previously extracted data from storage
    const stored = await new Promise(resolve =>
      chrome.storage.local.get(['scrapeflow_data'], resolve)
    );
    if (stored.scrapeflow_data && stored.scrapeflow_data.length > 0) {
      scrapedData = stored.scrapeflow_data;
      updatePreview(scrapedData);
    }

    // Check if onboarding was previously dismissed
    const onboardingDismissed = await new Promise(resolve =>
      chrome.storage.local.get(['scrapeflow_onboarding_dismissed'], resolve)
    );
    if (onboardingDismissed.scrapeflow_onboarding_dismissed) {
      const onboardingEl = document.getElementById('onboarding');
      if (onboardingEl) onboardingEl.classList.add('hidden');
    }

    try {
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'getStatus' });
      if (response && response.isScraping) {
        isScraping = true;
        updateUI(true);
        // Fetch existing detection results
        fetchDetectionResults(tab.id);
      }
    } catch {
      // Content script not loaded — this is normal on chrome:// pages
      // or when the content script hasn't been injected yet
    }

    // Update tier badge regardless of content script state
    updateTierBadge();

    // Load and render analytics stats
    renderStats();
  }

  // ── Stats Section ────────────────────────────────────────────────────

  async function renderStats() {
    if (!window.ScrapeFlowAnalytics) return;
    const stats = await ScrapeFlowAnalytics.getStats();
    const statsEl = document.getElementById('statsSection');
    if (!statsEl) return;

    statsEl.innerHTML = `
      <div class="stats-row">
        <span class="stats-label">📊 Scrapes this month</span>
        <span class="stats-value">${stats.scrapesThisMonth}</span>
      </div>
      <div class="stats-row">
        <span class="stats-label">📂 Popup opens this week</span>
        <span class="stats-value">${stats.popupOpensThisWeek}</span>
      </div>
      <div class="stats-row">
        <span class="stats-label">📅 Days since install</span>
        <span class="stats-value">${stats.daysSinceInstall}</span>
      </div>
    `;
    statsEl.classList.remove('hidden');
  }

  // ── Tier Badge ───────────────────────────────────────────────────────

  async function updateTierBadge() {
    if (!window.ScrapeFlowTiers) return;
    const tier = await ScrapeFlowTiers.getTier();
    const usage = await ScrapeFlowTiers.getUsage();
    const currentMonth = new Date().toISOString().slice(0, 7);
    const rowsUsed = usage.month === currentMonth ? usage.rowsThisMonth : 0;

    const tierLabels = { free: 'Free — 50 rows/mo', pro: 'Pro — Unlimited', team: 'Team — Unlimited' };
    tierBadge.textContent = tierLabels[tier] || 'Free — 50 rows/mo';
    tierBadge.className = 'tier-badge ' + tier;

    // Show upgrade banner for free tier near limit
    if (tier === 'free' && rowsUsed >= 40 && !tierBannerDismissed) {
      upgradeBannerText.textContent = `You've used ${rowsUsed}/50 rows. Upgrade to Pro for unlimited.`;
      upgradeBanner.classList.remove('hidden');
    }
  }

  // ── Upgrade Banner tracking ──────────────────────────────────────────

  if (upgradeBannerBtn) {
    upgradeBannerBtn.addEventListener('click', async () => {
      if (window.ScrapeFlowAnalytics) {
        await ScrapeFlowAnalytics.track('upgrade_clicked');
      }
    });
  }

  if (upgradeBannerDismiss) {
    upgradeBannerDismiss.addEventListener('click', () => {
      tierBannerDismissed = true;
      upgradeBanner.classList.add('hidden');
    });
  }

  // ── Onboarding dismiss ────────────────────────────────────────────────

  if (dismissOnboarding) {
    dismissOnboarding.addEventListener('click', () => {
      const onboarding = document.getElementById('onboarding');
      if (onboarding) onboarding.classList.add('hidden');
      chrome.storage.local.set({ scrapeflow_onboarding_dismissed: true });
    });
  }

  async function fetchDetectionResults(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { action: 'getDetectionResults' });
      if (response && response.results && response.results.length > 0) {
        currentDetections = response.results;
        renderDetectionResults(currentDetections);
      }
    } catch {
      // Ignore
    }
  }

  // ── Start / Clear ────────────────────────────────────────────────────

  startBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    try {
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'startScraping' });
      if (response && response.success) {
        isScraping = true;
        updateUI(true);
        // Run detection
        runDetection(tab.id);
      }
    } catch (err) {
      // Inject content script if not already
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content/detection.js', 'content/content-script.js']
      });
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['content/content-style.css']
      });
      // Retry
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'startScraping' });
      if (response && response.success) {
        isScraping = true;
        updateUI(true);
        runDetection(tab.id);
      }
    }
  });

  clearBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'clearScraping' });
    } catch {}
    isScraping = false;
    scrapedData = [];
    currentDetections = [];
    // Clear persisted data
    chrome.storage.local.remove('scrapeflow_data');
    updateUI(false);
    detectionResultsEl.classList.add('hidden');
    detectionListEl.innerHTML = '';
  });

  // ── Detection ────────────────────────────────────────────────────────

  async function runDetection(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { action: 'detectStructures' });
      if (response && response.results) {
        currentDetections = response.results;
        renderDetectionResults(currentDetections);
      }
    } catch {
      // Content script may not be ready
    }
  }

  function renderDetectionResults(results) {
    if (!results || results.length === 0) {
      detectionResultsEl.classList.add('hidden');
      return;
    }

    detectionResultsEl.classList.remove('hidden');
    detectionListEl.innerHTML = '';

    results.forEach((r) => {
      const item = document.createElement('div');
      item.className = 'detection-item';

      const conf = Math.round(r.confidence * 100);
      const confClass = conf >= 75 ? 'high' : conf >= 50 ? 'medium' : 'low';
      const typeIcon = r.type === 'table' ? '📊' : r.type === 'list' ? '📋' : '🃏';

      const columnsHtml = r.columns
        .slice(0, 6)
        .map((c) => `<span class="detection-column-tag">${escapeHtml(c)}</span>`)
        .join('');

      item.innerHTML = `
        <div class="detection-item-header">
          <span class="detection-type ${r.type}">${typeIcon} ${r.type}</span>
          <span class="detection-meta">${r.rowCount} items · ${r.columns.length} fields</span>
        </div>
        <div class="confidence-bar-bg">
          <div class="confidence-bar-fill ${confClass}" style="width: ${conf}%"></div>
        </div>
        <div class="confidence-label">Confidence: ${conf}%</div>
        <div class="detection-columns">${columnsHtml}</div>
        <button class="btn-auto-extract" data-detection-id="${r.id}">
          ⚡ Auto-Extract
        </button>
      `;

      detectionListEl.appendChild(item);
    });

    // Bind auto-extract buttons
    detectionListEl.querySelectorAll('.btn-auto-extract').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        const detectionId = e.target.dataset.detectionId;
        await handleAutoExtract(detectionId);
      });
    });
  }

  async function handleAutoExtract(detectionId) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'autoExtract',
        detectionId,
      });
      if (response && response.data) {
        scrapedData = response.data;
        updatePreview(scrapedData);
        // Increment usage for auto-extracted rows
        if (window.ScrapeFlowTiers && scrapedData.length > 0) {
          const newRows = scrapedData.length;
          await ScrapeFlowTiers.incrementUsage(newRows);
          await updateTierBadge();
        }
      }
    } catch {
      // Ignore
    }
  }

  // ── Export ───────────────────────────────────────────────────────────

  exportCsv.addEventListener('click', async () => {
    if (scrapedData.length === 0) return;
    if (window.ScrapeFlowTiers) {
      const check = await ScrapeFlowTiers.canExport('csv');
      if (!check.allowed) {
        upgradeBannerText.textContent = check.reason;
        upgradeBanner.classList.remove('hidden');
        return;
      }
    }
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const pageTitle = (tab?.title || 'export').replace(/[^a-z0-9_-]/gi, '_').substring(0, 40);
    const date = new Date().toISOString().slice(0, 10);
    const csv = toCSV(scrapedData);
    download(csv, `scrapeflow_${pageTitle}_${date}.csv`, 'text/csv');
    if (window.ScrapeFlowTiers) {
      await ScrapeFlowTiers.incrementUsage(scrapedData.length);
      await updateTierBadge();
    }
    if (window.ScrapeFlowAnalytics) {
      await ScrapeFlowAnalytics.track('export_csv', { rows: scrapedData.length });
    }
  });

  exportJson.addEventListener('click', async () => {
    if (scrapedData.length === 0) return;
    if (window.ScrapeFlowTiers) {
      const check = await ScrapeFlowTiers.canExport('json');
      if (!check.allowed) {
        upgradeBannerText.textContent = check.reason;
        upgradeBanner.classList.remove('hidden');
        return;
      }
    }
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const pageTitle = (tab?.title || 'export').replace(/[^a-z0-9_-]/gi, '_').substring(0, 40);
    const date = new Date().toISOString().slice(0, 10);
    const json = JSON.stringify(scrapedData, null, 2);
    download(json, `scrapeflow_${pageTitle}_${date}.json`, 'application/json');
    if (window.ScrapeFlowTiers) {
      await ScrapeFlowTiers.incrementUsage(scrapedData.length);
      await updateTierBadge();
    }
    if (window.ScrapeFlowAnalytics) {
      await ScrapeFlowAnalytics.track('export_json', { rows: scrapedData.length });
    }
  });

  // ── UI helpers ───────────────────────────────────────────────────────

  function updateUI(active) {
    if (active) {
      startBtn.textContent = 'Scraping Active...';
      startBtn.disabled = true;
      clearBtn.disabled = false;
      statusEl.textContent = 'Click on page elements to capture data';
      statusEl.className = 'status active';
    } else {
      startBtn.textContent = 'Start Scraping';
      startBtn.disabled = false;
      clearBtn.disabled = true;
      statusEl.textContent = 'Click "Start Scraping" to begin';
      statusEl.className = 'status';
      previewEl.classList.add('hidden');
      exportActions.classList.add('hidden');
    }
  }

  function updatePreview(data) {
    scrapedData = data;
    if (data.length === 0) {
      previewEl.classList.add('hidden');
      exportActions.classList.add('hidden');
      return;
    }

    // Hide onboarding, show data
    const onboarding = document.getElementById('onboarding');
    if (onboarding) onboarding.classList.add('hidden');

    // Show success status
    statusEl.textContent = `✅ ${data.length} rows extracted — ready to export!`;
    statusEl.className = 'status success';

    const columns = Object.keys(data[0]);
    let html = '<table><thead><tr>';
    columns.forEach((col) => {
      html += `<th>${escapeHtml(col)}</th>`;
    });
    html += '</tr></thead><tbody>';
    // Show max 50 rows in preview
    const previewData = data.slice(0, 50);
    previewData.forEach((row) => {
      html += '<tr>';
      columns.forEach((col) => {
        html += `<td>${escapeHtml(String(row[col] ?? ''))}</td>`;
      });
      html += '</tr>';
    });
    if (data.length > 50) {
      html += `<tr><td colspan="${columns.length}" style="text-align:center;color:#666;font-style:italic;">... and ${data.length - 50} more rows</td></tr>`;
    }
    html += '</tbody></table>';

    previewTable.innerHTML = html;
    const totalSize = formatBytes(jsonBlobSize(data));
    countEl.textContent = `(${data.length} rows · ${totalSize} JSON)`;
    previewEl.classList.remove('hidden');
    exportActions.classList.remove('hidden');
  }

  function toCSV(data) {
    if (data.length === 0) return '';
    const columns = Object.keys(data[0]);
    const header = columns.join(',');
    const rows = data.map((row) =>
      columns
        .map((col) => {
          const val = String(row[col] ?? '');
          return val.includes(',') || val.includes('"') || val.includes('\n')
            ? `"${val.replace(/"/g, '""')}"`
            : val;
        })
        .join(',')
    );
    return [header, ...rows].join('\n');
  }

  function download(content, filename, type) {
    const blob = new Blob([content], { type });
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      chrome.downloads.download({
        url: dataUrl,
        filename: filename,
        saveAs: true,
      });
    };
    reader.readAsDataURL(blob);
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function jsonBlobSize(data) {
    return new Blob([JSON.stringify(data, null, 2)]).size;
  }

  function csvBlobSize(data) {
    if (data.length === 0) return 0;
    const columns = Object.keys(data[0]);
    const header = columns.join(',');
    const rows = data.map(row =>
      columns.map(col => {
        const val = String(row[col] ?? '');
        return val.includes(',') || val.includes('"') || val.includes('\n')
          ? `"${val.replace(/"/g, '""')}"` : val;
      }).join(',')
    );
    return new Blob([[header, ...rows].join('\n')]).size;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ── Message listener ─────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'dataUpdated') {
      updatePreview(msg.data);
    }
    if (msg.action === 'structureSelected' && msg.detection) {
      // Highlight the selected detection in the list
      const det = msg.detection;
      statusEl.textContent = `Selected: ${det.type} — ${det.rowCount} items (${Math.round(det.confidence * 100)}% confidence)`;
    }
  });

  init();
})();

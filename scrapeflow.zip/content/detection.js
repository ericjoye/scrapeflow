/**
 * @fileoverview Auto-detection module for ScrapeFlow. Analyzes the DOM
 * to find data tables, lists, and card layouts using heuristic scoring.
 * @author Builder Agent
 * @date 2026-06-18
 */

/**
 * @typedef {Object} ColumnInfo
 * @property {string} name - Normalised column/field name.
 * @property {string} source - How the name was inferred (e.g. "thead", "heading", "pattern").
 */

/**
 * @typedef {Object} DetectionResult
 * @property {string} id - Unique detection identifier.
 * @property {'table'|'list'|'card'} type - Kind of structure detected.
 * @property {Element} element - The root DOM element of the structure.
 * @property {string[]} columns - Inferred column/field names.
 * @property {number} rowCount - Number of items / rows detected.
 * @property {number} confidence - Score 0-1 indicating detection confidence.
 * @property {number} index - Page-level index for display ordering.
 */

(function () {
  'use strict';

  try {

  // ── Helpers ──────────────────────────────────────────────────────────

  /**
   * Normalise a human-readable label into a snake_case field name.
   * @param {string} raw
   * @returns {string}
   */
  function normaliseField(raw) {
    return raw
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s_-]/g, '')
      .replace(/\s+/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '')
      || 'field'; // fallback
  }

  /**
   * Detect whether a list of text strings is consistent in format.
   * Returns a ratio 0-1 where 1 = perfectly consistent.
   * @param {string[]} values
   * @returns {number}
   */
  function consistencies(values) {
    if (values.length < 2) return 1;
    const checks = values.map((v) => ({
      isNumber: /^\s*[-+]?\d[\d,.]*\s*$/.test(v),
      hasCurrency: /[$€£¥₹]\s?/.test(v),
      isDate: /\d{1,4}[-/]\d{1,2}[-/]\d{1,4}/.test(v),
      wordCount: v.split(/\s+/).length,
    }));
    let score = 0;
    const n = checks.length;
    // numeric consistency
    const numRatio = checks.filter((c) => c.isNumber).length / n;
    const curRatio = checks.filter((c) => c.hasCurrency).length / n;
    const dateRatio = checks.filter((c) => c.isDate).length / n;
    // word-count consistency
    const avgWords = checks.reduce((s, c) => s + c.wordCount, 0) / n;
    const wordStd = Math.sqrt(
      checks.reduce((s, c) => s + (c.wordCount - avgWords) ** 2, 0) / n
    );
    const wordScore = Math.max(0, 1 - wordStd / 3);
    score = Math.max(numRatio, curRatio, dateRatio, wordScore);
    return Math.min(1, score);
  }

  /**
   * Find the nearest heading sibling or ancestor label for field context.
   * @param {Element} element
   * @returns {string|null}
   */
  function findNearbyHeading(element) {
    // Check previous siblings walked up the tree
    let current = element;
    for (let i = 0; i < 5; i++) {
      if (!current) break;
      // Check previous siblings
      let sibling = current.previousElementSibling;
      while (sibling) {
        const tag = sibling.tagName.toLowerCase();
        if (/^h[1-4]$/.test(tag)) {
          const text = sibling.textContent.trim();
          if (text) return text;
        }
        sibling = sibling.previousElementSibling;
      }
      current = current.parentElement;
    }
    // Check aria-label on the element or parent
    const withAria = element.closest('[aria-label]');
    if (withAria) return withAria.getAttribute('aria-label');
    return null;
  }

  // ── Table Detection ──────────────────────────────────────────────────

  /**
   * Detect data tables.
   * @returns {DetectionResult[]}
   */
  function detectTables() {
    const results = [];
    const tables = document.querySelectorAll('table');
    let tblIndex = 0;

    tables.forEach((table) => {
      // Gather rows from tbody or the table directly
      let rows = table.querySelectorAll(':scope > tbody > tr');
      if (!rows.length) rows = table.querySelectorAll(':scope > tr');
      if (rows.length < 3) return; // require at least 3 rows

      // ── Column inference ──
      let columns = [];
      // 1. Try thead
      const theadCells = table.querySelectorAll(':scope > thead > tr > th, :scope > thead > tr > td');
      if (theadCells.length > 0) {
        columns = Array.from(theadCells).map((th) =>
          normaliseField(th.textContent)
        );
      }
      // 2. Fallback: use first row header detection
      if (!columns.length && rows.length > 0) {
        const firstRowCells = rows[0].querySelectorAll(':scope > td, :scope > th');
        const headerCandidates = Array.from(firstRowCells).map((td) =>
          td.textContent.trim()
        );
        // Heuristic: if first row is all th tags OR its cells are shorter than
        // the second row's cells (headers tend to be short), treat as headers.
        const isHeaderRow =
          rows[0].querySelectorAll(':scope > th').length === firstRowCells.length ||
          headerCandidates.every((t) => t.length <= 30);
        if (isHeaderRow) {
          columns = headerCandidates.map((t) => normaliseField(t));
        }
      }
      // 3. Fallback: generic names from column count
      const colCount = rows[0]?.querySelectorAll(':scope > td, :scope > th').length || 0;
      if (!columns.length && colCount > 0) {
        columns = Array.from({ length: colCount }, (_, i) => `col_${i + 1}`);
      }

      // ── Scoring ──
      const rowCount = rows.length;
      // Column consistency: check that most rows have the same cell count
      const colCounts = Array.from(rows).map(
        (r) => r.querySelectorAll(':scope > td, :scope > th').length
      );
      const modeCount = colCounts.filter((c) => c === colCount).length;
      const colConsistency = modeCount / rowCount;

      // Text-to-link ratio (data tables tend to have more text than links)
      const allText = table.textContent.trim().length;
      const linkText = Array.from(table.querySelectorAll('a')).reduce(
        (s, a) => s + a.textContent.trim().length,
        0
      );
      const textRatio = allText > 0 ? 1 - linkText / allText : 1;

      // Data consistency across rows (sample first column values)
      const firstColValues = Array.from(rows)
        .map((r) => {
          const cells = r.querySelectorAll(':scope > td');
          return cells.length > 0 ? cells[0].textContent.trim() : '';
        })
        .filter(Boolean);
      const dataConsistency = consistencies(firstColValues);

      // Confidence formula
      const confidence = Math.min(
        1,
        colConsistency * 0.35 +
          textRatio * 0.2 +
          dataConsistency * 0.25 +
          Math.min(1, rowCount / 20) * 0.2
      );

      results.push({
        id: `table-${tblIndex}`,
        type: 'table',
        element: table,
        columns,
        rowCount,
        confidence: Math.round(confidence * 100) / 100,
        index: tblIndex,
      });

      tblIndex++;
    });

    return results;
  }

  // ── List Detection ───────────────────────────────────────────────────

  /**
   * Detect list structures (ul/ol).
   * @returns {DetectionResult[]}
   */
  function detectLists() {
    const results = [];
    const lists = document.querySelectorAll('ul, ol');
    let listIndex = 0;

    lists.forEach((list) => {
      const items = list.querySelectorAll(':scope > li');
      if (items.length < 3) return;

      // ── Column / field inference ──
      let columns = [];
      // Try to infer from the first item's child structure
      const firstItem = items[0];
      const children = firstItem.children;
      if (children.length > 1) {
        // Multiple children → each is a field
        Array.from(children).forEach((child) => {
          const label =
            child.getAttribute('aria-label') ||
            child.dataset?.label ||
            child.textContent.trim().split('\n')[0].substring(0, 30) ||
            '';
          columns.push(normaliseField(label));
        });
      } else {
        // Single content item → look for heading context
        const heading = findNearbyHeading(list);
        if (heading) {
          columns = [normaliseField(heading)];
        } else {
          columns = ['item'];
        }
      }

      // ── Scoring ──
      const rowCount = items.length;

      // Consistency: do all items have similar structure?
      const childCounts = Array.from(items).map((li) => li.children.length);
      const modeChild = childCounts.filter((c) => c === childCounts[0]).length;
      const structureConsistency = modeChild / rowCount;

      // Text-to-link ratio
      const allText = list.textContent.trim().length;
      const linkText = Array.from(list.querySelectorAll('a')).reduce(
        (s, a) => s + a.textContent.trim().length,
        0
      );
      const textRatio = allText > 0 ? 1 - linkText / allText : 0.5;

      // Content consistency (sample text lengths)
      const textLengths = Array.from(items).map(
        (li) => li.textContent.trim().length
      );
      const avgLen = textLengths.reduce((a, b) => a + b, 0) / rowCount;
      const stdLen = Math.sqrt(
        textLengths.reduce((s, l) => s + (l - avgLen) ** 2, 0) / rowCount
      );
      const lengthConsistency = Math.max(0, 1 - stdLen / (avgLen || 1));

      const confidence = Math.min(
        1,
        structureConsistency * 0.35 +
          textRatio * 0.15 +
          lengthConsistency * 0.25 +
          Math.min(1, rowCount / 15) * 0.25
      );

      results.push({
        id: `list-${listIndex}`,
        type: 'list',
        element: list,
        columns,
        rowCount,
        confidence: Math.round(confidence * 100) / 100,
        index: listIndex,
      });

      listIndex++;
    });

    return results;
  }

  // ── Card Detection ───────────────────────────────────────────────────

  /**
   * Detect card layouts (repeating sibling elements with same class).
   * @returns {DetectionResult[]}
   */
  function detectCards() {
    const results = [];
    let cardIndex = 0;

    // Strategy: find parent containers whose direct children share the same
    // className and appear 3+ times.
    const parents = new Set();
    const candidates = document.querySelectorAll(
      'div, article, section, li'
    );

    candidates.forEach((el) => {
      const parent = el.parentElement;
      if (!parent || parents.has(parent)) return;
      if (parent === document.body) return;

      const tag = el.tagName.toLowerCase();
      const cls = el.className;
      if (!cls || cls.includes(' ') === false) return; // need some class specificity

      const siblings = parent.querySelectorAll(`:scope > ${tag}.${CSS.escape(cls)}`);
      if (siblings.length >= 3) {
        parents.add(parent);

        // ── Column / field inference ──
        const firstCard = siblings[0];
        const columns = inferCardFields(firstCard);

        // ── Scoring ──
        const rowCount = siblings.length;

        // Structure consistency: do all cards have similar child structure?
        const childTags = Array.from(siblings).map((card) =>
          Array.from(card.children)
            .map((c) => c.tagName.toLowerCase())
            .join(',')
        );
        const uniqueStructures = new Set(childTags).size;
        const structureConsistency = 1 / uniqueStructures;

        // Text-to-link ratio
        const allText = Array.from(siblings).reduce(
          (s, c) => s + c.textContent.trim().length,
          0
        );
        const linkText = Array.from(parent.querySelectorAll('a')).reduce(
          (s, a) => s + a.textContent.trim().length,
          0
        );
        const textRatio = allText > 0 ? 1 - linkText / allText : 0.5;

        // Content consistency
        const textLengths = Array.from(siblings).map(
          (c) => c.textContent.trim().length
        );
        const avgLen = textLengths.reduce((a, b) => a + b, 0) / rowCount;
        const stdLen = Math.sqrt(
          textLengths.reduce((s, l) => s + (l - avgLen) ** 2, 0) / rowCount
        );
        const lengthConsistency = Math.max(0, 1 - stdLen / (avgLen || 1));

        const confidence = Math.min(
          1,
          structureConsistency * 0.35 +
            textRatio * 0.15 +
            lengthConsistency * 0.25 +
            Math.min(1, rowCount / 15) * 0.25
        );

        results.push({
          id: `card-${cardIndex}`,
          type: 'card',
          element: parent,
          columns,
          rowCount,
          confidence: Math.round(confidence * 100) / 100,
          index: cardIndex,
        });

        cardIndex++;
      }
    });

    return results;
  }

  /**
   * Infer field names from a card element's child structure.
   * @param {Element} card
   * @returns {string[]}
   */
  function inferCardFields(card) {
    const fields = [];
    const children = card.children;

    Array.from(children).forEach((child) => {
      const tag = child.tagName.toLowerCase();
      const cls = (child.className || '').toLowerCase();
      const ariaLabel = child.getAttribute('aria-label') || '';

      if (tag === 'a') {
        // Link → title or link
        if (cls.includes('title') || cls.includes('name') || cls.includes('link')) {
          fields.push('title');
        } else {
          fields.push('link');
        }
      } else if (/^h[1-6]$/.test(tag)) {
        fields.push('title');
      } else if (tag === 'img') {
        fields.push('image');
      } else if (tag === 'span' || tag === 'div' || tag === 'p') {
        // Class-based inference
        if (/price|cost|amount|\$/.test(cls)) {
          fields.push('price');
        } else if (/date|time/.test(cls)) {
          fields.push('date');
        } else if (/desc|summary|excerpt/.test(cls)) {
          fields.push('description');
        } else if (/author|user|name/.test(cls)) {
          fields.push('author');
        } else if (/cat|tag|label/.test(cls)) {
          fields.push('category');
        } else if (/rating|star|score/.test(cls)) {
          fields.push('rating');
        } else if (ariaLabel) {
          fields.push(normaliseField(ariaLabel));
        } else {
          // Use text content hint
          const text = child.textContent.trim();
          if (/^\s*[$€£¥₹]?\s*\d/.test(text)) {
            fields.push('price');
          } else if (text.length < 30) {
            fields.push('label');
          } else {
            fields.push('text');
          }
        }
      } else {
        fields.push(tag);
      }
    });

    return fields.length > 0 ? fields : ['content'];
  }

  // ── Public API ───────────────────────────────────────────────────────

  /**
   * Detect all data structures on the page.
   * @returns {DetectionResult[]}
   */
  function detectPageStructures() {
    const tables = detectTables();
    const lists = detectLists();
    const cards = detectCards();

    // Merge and sort by confidence descending
    const all = [...tables, ...lists, ...cards].sort(
      (a, b) => b.confidence - a.confidence
    );

    // Re-index after sort
    all.forEach((d, i) => {
      d.index = i;
    });

    return all;
  }

  // Expose globally for the content script (IIFE pattern, no modules)
  window.ScrapeFlowDetection = {
    detectPageStructures,
    // Exposed for testing
    _normaliseField: normaliseField,
    _consistencies: consistencies,
    _findNearbyHeading: findNearbyHeading,
    _inferCardFields: inferCardFields,
  };
  } catch (err) {
    console.error('[ScrapeFlow] Detection module error:', err);
  }
})();

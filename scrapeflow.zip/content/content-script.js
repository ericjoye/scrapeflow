/**
 * @fileoverview ScrapeFlow content script. Handles element selection,
 * data extraction, smart expand, and page structure auto-detection.
 * @author Builder Agent
 * @date 2026-06-18
 */
(function () {
  'use strict';

  try {
    if (window.__scrapeFlowInjected) return;
    window.__scrapeFlowInjected = true;

    // ── State ────────────────────────────────────────────────────────────

    let isScraping = false;
    let scrapedData = [];
    let highlightedEl = null;
    let overlayEl = null;
    let detectionResults = [];
    let selectedStructure = null;
    let smartExpandEnabled = true;

    // ── Message Listener ─────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {
      case 'getStatus':
        sendResponse({ isScraping });
        break;
      case 'startScraping':
        startScraping();
        sendResponse({ success: true });
        break;
      case 'clearScraping':
        stopScraping();
        scrapedData = [];
        sendResponse({ success: true });
        break;
      case 'detectStructures':
        detectionResults = runDetection();
        sendResponse({ success: true, results: serialiseResults(detectionResults) });
        break;
      case 'autoExtract':
        autoExtract(msg.detectionId);
        sendResponse({ success: true, data: scrapedData });
        break;
      case 'getDetectionResults':
        sendResponse({ results: serialiseResults(detectionResults) });
        break;
    }
    return true;
  });

  // ── Detection ────────────────────────────────────────────────────────

  function runDetection() {
    if (window.ScrapeFlowDetection) {
      detectionResults = window.ScrapeFlowDetection.detectPageStructures();
      paintDetectionOverlays();
      return detectionResults;
    }
    return [];
  }

  /**
   * Strip Element references for JSON-serialisable results.
   */
  function serialiseResults(results) {
    return results.map((r) => ({
      id: r.id,
      type: r.type,
      columns: r.columns,
      rowCount: r.rowCount,
      confidence: r.confidence,
      index: r.index,
    }));
  }

  /**
   * Add dashed outlines to detected structures.
   */
  function paintDetectionOverlays() {
    clearDetectionOverlays();
    detectionResults.forEach((r) => {
      if (r.element && r.element.classList) {
        r.element.classList.add('scrapeflow-detected');
      }
    });
  }

  function clearDetectionOverlays() {
    document.querySelectorAll('.scrapeflow-detected').forEach((el) => {
      el.classList.remove('scrapeflow-detected');
    });
    document.querySelectorAll('.scrapeflow-selected').forEach((el) => {
      el.classList.remove('scrapeflow-selected');
    });
  }

  // ── Scraping ─────────────────────────────────────────────────────────

  function startScraping() {
    isScraping = true;
    scrapedData = []; // Reset data for new session
    document.addEventListener('mouseover', onMouseOver, true);
    document.addEventListener('mouseout', onMouseOut, true);
    document.addEventListener('click', onClick, true);
    injectOverlay();
    // Run detection only for pro+ tier
    if (window.ScrapeFlowTiers) {
      ScrapeFlowTiers.canUseDetection().then((allowed) => {
        if (allowed) {
          runDetection();
          updateOverlayWithDetections();
        }
      }).catch(() => {});
    } else {
      // Tier manager not loaded — run detection (content script context)
      runDetection();
      updateOverlayWithDetections();
    }
  }

  function stopScraping() {
    isScraping = false;
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('mouseout', onMouseOut, true);
    document.removeEventListener('click', onClick, true);
    removeHighlight();
    removeOverlay();
    clearDetectionOverlays();
    detectionResults = [];
    selectedStructure = null;
  }

  // ── Keyboard Shortcuts ────────────────────────────────────────────────

  document.addEventListener('keydown', (e) => {
    if (!isScraping) return;
    // Escape to stop scraping
    if (e.key === 'Escape') {
      stopScraping();
      scrapedData = [];
      chrome.runtime.sendMessage({ action: 'scrapingStopped' });
    }
    // Space to toggle smart expand
    if (e.key === ' ' && e.target === document.body) {
      e.preventDefault();
      smartExpandEnabled = !smartExpandEnabled;
      showToast(smartExpandEnabled ? 'Smart Expand: ON' : 'Smart Expand: OFF');
    }
  });

  // ── Toast Notifications ───────────────────────────────────────────────

  function showToast(message, type = 'info') {
    const existing = document.querySelector('.scrapeflow-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `scrapeflow-toast scrapeflow-toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    // Animate in
    requestAnimationFrame(() => {
      toast.classList.add('scrapeflow-toast-visible');
    });

    // Auto-dismiss
    setTimeout(() => {
      toast.classList.remove('scrapeflow-toast-visible');
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ── Mouse handlers ───────────────────────────────────────────────────

  function onMouseOver(e) {
    if (!isScraping) return;
    removeHighlight();
    highlightedEl = e.target;
    highlightedEl.classList.add('scrapeflow-highlight');
  }

  function onMouseOut(e) {
    if (!isScraping) return;
    e.target.classList.remove('scrapeflow-highlight');
  }

  function onClick(e) {
    if (!isScraping) return;
    e.preventDefault();
    e.stopPropagation();

    const el = e.target;

    // Check if click is inside a detected structure → select it
    const detection = findContainingDetection(el);
    if (detection) {
      selectStructure(detection, el);
      return;
    }

    // Fallback: regular element extraction
    const data = extractData(el);
    if (data) {
      captureData(data, el);
      showToast(`Captured: ${Object.keys(data).length} fields`, 'success');
    }
  }

  /**
   * Find the DetectionResult whose element contains `el`.
   */
  function findContainingDetection(el) {
    for (const r of detectionResults) {
      if (r.element && r.element.contains(el)) {
        return r;
      }
    }
    return null;
  }

  /**
   * Select a detected structure and apply visual feedback.
   */
  function selectStructure(detection, clickedEl) {
    selectedStructure = detection.id;

    // Update outlines
    document.querySelectorAll('.scrapeflow-selected').forEach((el) => {
      el.classList.remove('scrapeflow-selected');
    });
    if (detection.element) {
      detection.element.classList.remove('scrapeflow-detected');
      detection.element.classList.add('scrapeflow-selected');
    }

    // Smart expand: if user clicked inside a row/card, extract all rows
    if (smartExpandEnabled) {
      offerSmartExpand(detection, clickedEl);
    }

    // Update overlay
    updateOverlaySelection(detection);

    // Notify background/popup
    chrome.runtime.sendMessage({
      action: 'structureSelected',
      detection: {
        id: detection.id,
        type: detection.type,
        columns: detection.columns,
        rowCount: detection.rowCount,
        confidence: detection.confidence,
      },
    });
  }

  /**
   * Offer smart expand: click one row → extract all rows from that structure.
   */
  function offerSmartExpand(detection, clickedEl) {
    const rows = getStructureRows(detection, clickedEl);
    if (!rows || rows.length <= 1) return;

    // Show a one-time prompt in the overlay
    showExpandPrompt(detection, rows);
  }

  /**
   * Get all rows/items from a detection, given an element inside one of them.
   */
  function getStructureRows(detection, clickedEl) {
    const root = detection.element;
    if (!root) return null;

    switch (detection.type) {
      case 'table':
        return Array.from(
          root.querySelectorAll(':scope > tbody > tr, :scope > tr')
        );
      case 'list':
        return Array.from(root.querySelectorAll(':scope > li'));
      case 'card': {
        // Re-derive the card selector
        const firstChild = root.firstElementChild;
        if (!firstChild) return null;
        const tag = firstChild.tagName.toLowerCase();
        const cls = firstChild.className;
        if (!cls) return null;
        return Array.from(
          root.querySelectorAll(`:scope > ${tag}.${CSS.escape(cls)}`)
        );
      }
      default:
        return null;
    }
  }

  /**
   * Smart expand: highlight the entire row/card containing `clickedEl`.
   */
  function smartExpand(clickedEl, detection) {
    const rows = getStructureRows(detection, clickedEl);
    if (!rows) return null;

    // Find which row contains clickedEl
    for (const row of rows) {
      if (row.contains(clickedEl)) {
        return row;
      }
    }
    return null;
  }

  /**
   * Show expand prompt in the overlay.
   */
  function showExpandPrompt(detection, rows) {
    if (!overlayEl) return;

    const box = overlayEl.querySelector('.scrapeflow-overlay-box');
    if (!box) return;

    const originalHTML = box.innerHTML;
    box.innerHTML = `
      <div class="scrapeflow-expand-prompt">
        <span>🔍 Found ${detection.rowCount} rows in ${detection.type}. Extract all?</span>
        <button id="sf-expand-yes" class="scrapeflow-btn-sm scrapeflow-btn-yes">Extract All</button>
        <button id="sf-expand-no" class="scrapeflow-btn-sm scrapeflow-btn-no">Just This</button>
      </div>
    `;

    const yesBtn = document.getElementById('sf-expand-yes');
    const noBtn = document.getElementById('sf-expand-no');

    yesBtn?.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      autoExtract(detection.id);
      box.innerHTML = originalHTML;
      updateOverlayWithDetections();
    });

    noBtn?.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      // Extract just the clicked row
      const row = smartExpand(highlightedEl, detection);
      if (row) {
        const data = extractRowData(row, detection);
        if (data) captureData(data, row);
      }
      box.innerHTML = originalHTML;
      updateOverlayWithDetections();
    });

    // Auto-dismiss after 5 seconds
    setTimeout(() => {
      if (box.querySelector('.scrapeflow-expand-prompt')) {
        box.innerHTML = originalHTML;
        updateOverlayWithDetections();
      }
    }, 5000);
  }

  /**
   * Extract all rows from a detection structure.
   */
  function autoExtract(detectionId) {
    const detection = detectionResults.find((r) => r.id === detectionId);
    if (!detection) return;

    const rows = getStructureRows(detection, detection.element);
    if (!rows) return;

    let newCount = 0;
    rows.forEach((row) => {
      const data = extractRowData(row, detection);
      if (data) {
        scrapedData.push(data);
        row.classList.add('scrapeflow-captured');
        newCount++;
      }
    });

    if (newCount === 0) {
      showToast('No data extracted', 'info');
      return;
    }

    // Persist to storage so popup can read it even after closing
    chrome.storage.local.set({ scrapeflow_data: scrapedData });

    // Show success toast on page
    showToast(`✅ Extracted ${newCount} rows! Open the extension to export.`, 'success');

    // Notify popup (in case it's still open)
    chrome.runtime.sendMessage({
      action: 'dataUpdated',
      data: scrapedData,
    });
  }

  /**
   * Extract structured data from a single row/cell item.
   */
  function extractRowData(row, detection) {
    const result = {};

    switch (detection.type) {
      case 'table': {
        const cells = row.querySelectorAll(':scope > td, :scope > th');
        cells.forEach((cell, i) => {
          const key = detection.columns[i] || `col_${i + 1}`;
          result[key] = cell.textContent.trim();
        });
        break;
      }
      case 'list': {
        // For lists, try structured extraction first, then fall back to text
        const children = row.children;
        if (children.length > 1) {
          Array.from(children).forEach((child, i) => {
            const key = detection.columns[i] || `field_${i + 1}`;
            result[key] = child.textContent.trim();
          });
        } else {
          result[detection.columns[0] || 'item'] = row.textContent.trim();
        }
        break;
      }
      case 'card': {
        // Use inferred field names from card children
        const cardFields = extractCardFieldsData(row);
        Object.assign(result, cardFields);
        break;
      }
    }

    return Object.keys(result).length > 0 ? result : null;
  }

  /**
   * Extract field data from a card element.
   */
  function extractCardFieldsData(card) {
    const result = {};
    const children = card.children;

    Array.from(children).forEach((child) => {
      const tag = child.tagName.toLowerCase();
      const cls = (child.className || '').toLowerCase();
      const text = child.textContent.trim();

      if (tag === 'a') {
        if (cls.includes('title') || cls.includes('name')) {
          result.title = text;
        } else {
          result.link = child.href || '';
          if (!result.title) result.title = text;
        }
      } else if (/^h[1-6]$/.test(tag)) {
        result.title = text;
      } else if (tag === 'img') {
        result.image = child.src || child.getAttribute('data-src') || '';
      } else if (/price|cost|amount|\$/.test(cls)) {
        result.price = text;
      } else if (/date|time/.test(cls)) {
        result.date = text;
      } else if (/desc|summary|excerpt/.test(cls)) {
        result.description = text;
      } else if (/author|user/.test(cls)) {
        result.author = text;
      } else if (/cat|tag/.test(cls)) {
        result.category = text;
      } else if (/rating|star|score/.test(cls)) {
        result.rating = text;
      } else if (text && Object.keys(result).length < 6) {
        const key = normaliseField(child.getAttribute('aria-label') || `field_${Object.keys(result).length + 1}`);
        result[key] = text;
      }
    });

    return result;
  }

  /**
   * Quick normalise without importing from detection module.
   */
  function normaliseField(raw) {
    return raw
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s_-]/g, '')
      .replace(/\s+/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '')
      || 'field';
  }

  // ── Legacy extraction (fallback for non-detected elements) ──────────

  function extractData(el) {
    const row = findRepeatingParent(el);
    if (!row) {
      return { text: el.textContent?.trim() || '' };
    }

    const result = {};

    // Try table cells
    const cells = row.querySelectorAll('td, th');
    if (cells.length > 0) {
      cells.forEach((cell, i) => {
        result[`col_${i + 1}`] = cell.textContent?.trim() || '';
      });
      return result;
    }

    // Try common patterns
    const links = row.querySelectorAll('a');
    const headings = row.querySelectorAll('h1, h2, h3, h4, h5, h6');
    const spans = row.querySelectorAll('span');
    const images = row.querySelectorAll('img');

    if (headings.length > 0) result.title = headings[0].textContent?.trim() || '';
    if (links.length > 0) {
      result.link = links[0].href || '';
      result.link_text = links[0].textContent?.trim() || '';
    }
    if (spans.length > 0) {
      spans.forEach((span, i) => {
        if (span.textContent?.trim()) {
          result[`field_${i + 1}`] = span.textContent.trim();
        }
      });
    }
    if (images.length > 0) {
      result.image = images[0].src || images[0].getAttribute('data-src') || '';
    }

    if (Object.keys(result).length === 0) {
      result.text = row.textContent?.trim() || '';
    }

    return result;
  }

  function findRepeatingParent(el) {
    let current = el;
    for (let i = 0; i < 10; i++) {
      if (!current || current === document.body) return el;

      const tag = current.tagName.toLowerCase();
      if (tag === 'tr' || tag === 'li' || tag === 'article') {
        return current;
      }

      const parent = current.parentElement;
      if (parent) {
        const siblings = parent.querySelectorAll(`:scope > ${tag}`);
        if (siblings.length >= 3) {
          return current;
        }
      }
      current = parent;
    }
    return el;
  }

  function captureData(data, el) {
    scrapedData.push(data);
    el.classList.add('scrapeflow-captured');
    el.classList.remove('scrapeflow-highlight');

    // ── Analytics tracking ──
    // Check if this is the first scrape
    chrome.storage.local.get(['scrapeflow_first_scrape'], (result) => {
      if (!result.scrapeflow_first_scrape) {
        chrome.storage.local.set({ scrapeflow_first_scrape: true });
        if (window.ScrapeFlowAnalytics) {
          ScrapeFlowAnalytics.track('first_scrape', { fields: Object.keys(data).length });
        }
      }
    });
    // Increment scrape count
    if (window.ScrapeFlowAnalytics) {
      ScrapeFlowAnalytics.track('scrape_count', { fields: Object.keys(data).length });
    }
    // Check free-tier row limit (50 rows/mo)
    chrome.storage.local.get(['scrapeflow_usage', 'scrapeflow_tier'], (result) => {
      const tier = result.scrapeflow_tier || 'free';
      if (tier === 'free') {
        const usage = result.scrapeflow_usage || { rowsThisMonth: 0, month: '' };
        const currentMonth = new Date().toISOString().slice(0, 7);
        const rowsThisMonth = usage.month === currentMonth ? usage.rowsThisMonth : 0;
        if (rowsThisMonth >= 50 && window.ScrapeFlowAnalytics) {
          ScrapeFlowAnalytics.track('limit_reached', { rowsThisMonth });
        }
      }
    });

    chrome.runtime.sendMessage({
      action: 'dataUpdated',
      data: scrapedData,
    });
  }

  // ── Overlay UI ────────────────────────────────────────────────────────

  function removeHighlight() {
    if (highlightedEl) {
      highlightedEl.classList.remove('scrapeflow-highlight');
      highlightedEl = null;
    }
  }

  function injectOverlay() {
    if (overlayEl) return;
    overlayEl = document.createElement('div');
    overlayEl.id = 'scrapeflow-overlay';
    overlayEl.innerHTML = `
      <div class="scrapeflow-overlay-box">
        <div class="scrapeflow-overlay-status">⚡ ScrapeFlow Active — Click elements to capture data</div>
        <div class="scrapeflow-detection-summary" id="sf-detection-summary"></div>
      </div>
    `;
    document.body.appendChild(overlayEl);
  }

  function removeOverlay() {
    if (overlayEl) {
      overlayEl.remove();
      overlayEl = null;
    }
  }

  function updateOverlayWithDetections() {
    if (!overlayEl) return;
    const summary = overlayEl.querySelector('#sf-detection-summary');
    if (!summary) return;

    if (detectionResults.length === 0) {
      summary.innerHTML = '';
      return;
    }

    const parts = detectionResults.map((r) => {
      const conf = Math.round(r.confidence * 100);
      return `<span class="scrapeflow-detection-chip" data-detection-id="${r.id}">
        ${r.type}(${r.rowCount}) ${conf}%
      </span>`;
    });

    summary.innerHTML = `<div class="scrapeflow-detection-chips">${parts.join(' ')}</div>`;

    // Bind click handlers on detection chips
    summary.querySelectorAll('.scrapeflow-detection-chip').forEach((chip) => {
      chip.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = e.target.dataset.detectionId;
        if (id) autoExtract(id);
      });
    });
  }

  function updateOverlaySelection(detection) {
    if (!overlayEl) return;
    const status = overlayEl.querySelector('.scrapeflow-overlay-status');
    if (status) {
      const conf = Math.round(detection.confidence * 100);
      status.innerHTML = `✅ Selected: <strong>${detection.type}</strong> — ${detection.rowCount} items, ${conf}% confidence`;
    }
  }
} catch (err) {
  console.error('[ScrapeFlow] Content script error:', err);
}
})();

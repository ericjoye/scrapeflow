# Privacy Policy — ScrapeFlow

**Last updated: June 18, 2026**

ScrapeFlow ("we", "our", or "the extension") is committed to protecting your privacy. This Privacy Policy explains how we handle information in connection with the ScrapeFlow Chrome extension.

## No Data Collection

ScrapeFlow does **not** collect, store, or transmit any data from your browsing activity, scraped content, or personal information. All data processing — including element detection, data capture, and export — occurs entirely within your local browser.

## No Tracking

ScrapeFlow does **not** use any tracking technologies, analytics services, cookies, or fingerprinting mechanisms. We do not monitor your browsing behavior, track which websites you visit, or record any usage patterns.

## No External API Calls

ScrapeFlow does **not** make any network requests to external servers. The extension operates fully offline after installation. No data is sent to our servers or any third-party services at any time.

## Local Storage Only

The only data stored by ScrapeFlow is kept locally in your browser using Chrome's `chrome.storage.local` API. This includes:

- Your license key (if you activate Pro or Team)
- Your current subscription tier
- Your monthly usage counter

This data never leaves your device.

## No Personal Information

ScrapeFlow does **not** collect any personally identifiable information (PII), including but not limited to your name, email address, IP address, or browsing history.

## Third-Party Services

ScrapeFlow does not integrate with, share data with, or rely on any third-party services, APIs, or data processors.

## Changes to This Policy

We may update this Privacy Policy from time to time. Any changes will be reflected in the updated version of this document.

## Contact

If you have any questions about this Privacy Policy, please contact us at:

**support@scrapeflow.app**

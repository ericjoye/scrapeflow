/**
 * @fileoverview ScrapeFlow background service worker. Relays messages
 * between popup and content scripts, handles detection and auto-extract.
 * Initializes default tier storage on install.
 * @author Builder Agent
 * @date 2026-06-18
 */
chrome.runtime.onInstalled.addListener(async () => {
  console.log('ScrapeFlow installed');
  // Track install date for analytics
  const installData = await new Promise(resolve =>
    chrome.storage.local.get(['scrapeflow_install_date'], resolve)
  );
  if (!installData.scrapeflow_install_date) {
    await new Promise(resolve =>
      chrome.storage.local.set({
        scrapeflow_install_date: new Date().toISOString().slice(0, 10),
      }, resolve)
    );
  }
  // Initialize default tier if not set
  const data = await new Promise(resolve =>
    chrome.storage.local.get(['scrapeflow_tier'], resolve)
  );
  if (!data.scrapeflow_tier) {
    await new Promise(resolve =>
      chrome.storage.local.set({
        scrapeflow_tier: 'free',
        scrapeflow_license: null,
        scrapeflow_usage: {
          rowsThisMonth: 0,
          month: new Date().toISOString().slice(0, 7),
        },
      }, resolve)
    );
  }

  // Reset monthly usage if the month has changed
  const usageData = await new Promise(resolve =>
    chrome.storage.local.get(['scrapeflow_usage'], resolve)
  );
  const usage = usageData.scrapeflow_usage;
  const currentMonth = new Date().toISOString().slice(0, 7);
  if (usage && usage.month !== currentMonth) {
    await new Promise(resolve =>
      chrome.storage.local.set({
        scrapeflow_usage: { rowsThisMonth: 0, month: currentMonth },
      }, resolve)
    );
  }
});

// chrome.downloads API is available via manifest "downloads" permission
// No background handler needed — popup calls chrome.downloads.download() directly

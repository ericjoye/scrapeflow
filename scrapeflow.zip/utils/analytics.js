/**
 * @fileoverview ScrapeFlow analytics helper. All events stored locally
 * via chrome.storage.local. No external services.
 * @author Optimizer Agent
 * @date 2026-06-18
 */
(function () {
  'use strict';

  const STORAGE_KEY = 'scrapeflow_analytics_events';
  const INSTALL_KEY = 'scrapeflow_install_date';

  // ── Helpers ──────────────────────────────────────────────────────────

  function today() {
    return new Date().toISOString().slice(0, 10);
  }

  function currentWeek() {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const days = Math.floor((now - startOfYear) / (24 * 60 * 60 * 1000));
    return `${now.getFullYear()}-W${Math.ceil((days + startOfYear.getDay() + 1) / 7)}`;
  }

  function currentMonth() {
    return new Date().toISOString().slice(0, 7);
  }

  async function getEvents() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (result) => {
        resolve(result[STORAGE_KEY] || []);
      });
    });
  }

  async function saveEvents(events) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [STORAGE_KEY]: events }, () => resolve());
    });
  }

  // ── Public API ───────────────────────────────────────────────────────

  /**
   * Track an event. Appends to the analytics_events array in chrome.storage.local.
   * @param {string} eventName
   * @param {Object} [data]  Optional extra data
   */
  async function track(eventName, data) {
    const events = await getEvents();
    events.push({
      event: eventName,
      data: data || {},
      timestamp: Date.now(),
      date: today(),
    });
    await saveEvents(events);
  }

  /**
   * Get a summary of analytics stats.
   * @returns {Object}
   */
  async function getStats() {
    const events = await getEvents();
    const installData = await new Promise((resolve) => {
      chrome.storage.local.get([INSTALL_KEY], (r) => resolve(r));
    });

    const installDate = installData[INSTALL_KEY] || null;
    const now = new Date();
    const daysSinceInstall = installDate
      ? Math.floor((now - new Date(installDate)) / (24 * 60 * 60 * 1000))
      : 0;

    const thisMonth = currentMonth();
    const thisWeek = currentWeek();

    let totalScrapes = 0;
    let totalExports = 0;
    let popupOpens = 0;
    let popupOpensThisWeek = 0;
    let scrapesThisMonth = 0;
    let firstScrapeDate = null;
    let limitReachedCount = 0;
    let upgradeViewedCount = 0;
    let upgradeClickedCount = 0;
    const exportFormats = { csv: 0, json: 0 };

    for (const ev of events) {
      if (ev.event === 'scrape_count') {
        totalScrapes++;
        if (ev.date.startsWith(thisMonth)) scrapesThisMonth++;
      }
      if (ev.event === 'first_scrape' && !firstScrapeDate) {
        firstScrapeDate = ev.date;
      }
      if (ev.event === 'export_csv') {
        totalExports++;
        exportFormats.csv++;
      }
      if (ev.event === 'export_json') {
        totalExports++;
        exportFormats.json++;
      }
      if (ev.event === 'popup_opened') {
        popupOpens++;
        // Approximate week matching by checking event timestamp
        const evDate = new Date(ev.timestamp);
        const startOfYear = new Date(evDate.getFullYear(), 0, 1);
        const days = Math.floor((evDate - startOfYear) / (24 * 60 * 60 * 1000));
        const evWeek = `${evDate.getFullYear()}-W${Math.ceil((days + startOfYear.getDay() + 1) / 7)}`;
        if (evWeek === thisWeek) popupOpensThisWeek++;
      }
      if (ev.event === 'limit_reached') limitReachedCount++;
      if (ev.event === 'upgrade_viewed') upgradeViewedCount++;
      if (ev.event === 'upgrade_clicked') upgradeClickedCount++;
    }

    return {
      totalScrapes,
      scrapesThisMonth,
      totalExports,
      exportFormats,
      popupOpens,
      popupOpensThisWeek,
      daysSinceInstall,
      firstScrapeDate,
      limitReachedCount,
      upgradeViewedCount,
      upgradeClickedCount,
      totalEvents: events.length,
    };
  }

  /**
   * Get the raw events array.
   * @returns {Array}
   */
  async function getEventsRaw() {
    return await getEvents();
  }

  // ── Exports ──────────────────────────────────────────────────────────

  window.ScrapeFlowAnalytics = {
    track,
    getStats,
    getEvents: getEventsRaw,
  };
})();

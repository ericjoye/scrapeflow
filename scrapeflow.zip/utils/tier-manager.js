/**
 * @fileoverview Tier management for ScrapeFlow. Handles license validation,
 * usage tracking, and feature gating. All data stored locally via chrome.storage.
 * @author Builder Agent
 * @date 2026-06-18
 */

(function () {
  'use strict';

  const STORAGE_KEYS = {
    LICENSE: 'scrapeflow_license',
    TIER: 'scrapeflow_tier',
    USAGE: 'scrapeflow_usage',
  };

  const FREE_ROW_LIMIT = 50;

  // ── Helpers ──────────────────────────────────────────────────────────

  function getCurrentMonth() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  }

  async function getStorage(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, (result) => resolve(result));
    });
  }

  async function setStorage(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set(data, () => resolve());
    });
  }

  // ── Public API ───────────────────────────────────────────────────────

  /**
   * Get the current tier from storage.
   * @returns {'free'|'pro'|'team'}
   */
  async function getTier() {
    const data = await getStorage([STORAGE_KEYS.TIER]);
    return data[STORAGE_KEYS.TIER] || 'free';
  }

  /**
   * Set a license key and update the tier accordingly.
   * @param {string} key  License key (PRO-XXXX or TEAM-XXXX)
   * @returns {{ tier: string, valid: boolean }}
   */
  async function setLicense(key) {
    if (!key || typeof key !== 'string') {
      return { tier: 'free', valid: false };
    }

    const trimmed = key.trim().toUpperCase();
    let tier = null;

    if (trimmed.startsWith('PRO-')) {
      tier = 'pro';
    } else if (trimmed.startsWith('TEAM-')) {
      tier = 'team';
    }

    if (!tier) {
      return { tier: 'free', valid: false };
    }

    await setStorage({
      [STORAGE_KEYS.LICENSE]: trimmed,
      [STORAGE_KEYS.TIER]: tier,
    });

    return { tier, valid: true };
  }

  /**
   * Get current month's usage.
   * @returns {{ rowsThisMonth: number, month: string }}
   */
  async function getUsage() {
    const data = await getStorage([STORAGE_KEYS.USAGE]);
    const usage = data[STORAGE_KEYS.USAGE];
    if (!usage) {
      return { rowsThisMonth: 0, month: getCurrentMonth() };
    }
    return usage;
  }

  /**
   * Increment the current month's row usage.
   * @param {number} rows  Number of rows to add.
   * @returns {number}  New total for the month.
   */
  async function incrementUsage(rows) {
    const usage = await getUsage();
    const currentMonth = getCurrentMonth();

    // Reset if month changed
    if (usage.month !== currentMonth) {
      usage.rowsThisMonth = 0;
      usage.month = currentMonth;
    }

    usage.rowsThisMonth += rows;
    await setStorage({ [STORAGE_KEYS.USAGE]: usage });
    return usage.rowsThisMonth;
  }

  /**
   * Check if the user can export in the given format.
   * @param {'csv'|'json'} format
   * @returns {{ allowed: boolean, reason?: string }}
   */
  async function canExport(format) {
    const tier = await getTier();

    // JSON export requires pro+
    if (format === 'json' && tier === 'free') {
      return { allowed: false, reason: 'JSON export requires Pro or Team.' };
    }

    // CSV: check row limit for free tier
    if (format === 'csv' && tier === 'free') {
      const usage = await getUsage();
      const currentMonth = getCurrentMonth();
      const rowsThisMonth = usage.month === currentMonth ? usage.rowsThisMonth : 0;
      if (rowsThisMonth >= FREE_ROW_LIMIT) {
        return {
          allowed: false,
          reason: `Free tier limit reached (${FREE_ROW_LIMIT}/${FREE_ROW_LIMIT} rows). Upgrade to Pro.`,
        };
      }
    }

    return { allowed: true };
  }

  /**
   * Check if the user can use AI auto-detection.
   * @returns {boolean}
   */
  async function canUseDetection() {
    const tier = await getTier();
    return tier === 'pro' || tier === 'team';
  }

  /**
   * Get remaining rows for the current month.
   * @returns {number}  Remaining rows (Infinity for paid tiers).
   */
  async function getRemainingRows() {
    const tier = await getTier();
    if (tier !== 'free') return Infinity;

    const usage = await getUsage();
    const currentMonth = getCurrentMonth();
    const rowsThisMonth = usage.month === currentMonth ? usage.rowsThisMonth : 0;
    return Math.max(0, FREE_ROW_LIMIT - rowsThisMonth);
  }

  /**
   * Reset monthly usage if the month has changed.
   * Call on extension startup.
   */
  async function resetMonthlyUsage() {
    const usage = await getUsage();
    const currentMonth = getCurrentMonth();
    if (usage.month !== currentMonth) {
      await setStorage({
        [STORAGE_KEYS.USAGE]: { rowsThisMonth: 0, month: currentMonth },
      });
    }
  }

  // ── Exports ──────────────────────────────────────────────────────────

  window.ScrapeFlowTiers = {
    getTier,
    setLicense,
    getUsage,
    incrementUsage,
    canExport,
    canUseDetection,
    getRemainingRows,
    resetMonthlyUsage,
    FREE_ROW_LIMIT,
  };
})();
